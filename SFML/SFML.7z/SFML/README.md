Author: Xuhua Huang 1879700

"main.cpp", "main.o" and "sfml-app" are dedicated to assignment part 1.
"part2.cpp", "part2.o" and "part2-app" are dedicated to part 2.
"part3.cpp", "part3.o" and "part3-app" are dedicated to part 3.
"part3custom.cpp"," .o" and " -app" are dedicated to modifying part of part 3.

name of the executables:
sfml-app
	green circle
part2-app
	custom picture and music
part3-app
	hello world
part3custom-app
	student name and color changed
